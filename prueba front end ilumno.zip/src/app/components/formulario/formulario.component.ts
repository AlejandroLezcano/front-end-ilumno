import { Component, OnInit, Output, EventEmitter} from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import swal from'sweetalert2';
@Component({
  selector: 'app-formulario',
  templateUrl: './formulario.component.html',
  styleUrls: ['./formulario.component.css']
})
export class FormularioComponent implements OnInit {
  public myGroup: FormGroup;
  @Output() data:EventEmitter<any> = new EventEmitter();;
  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.myGroup = this.formBuilder.group({
      marca:['', Validators.required],
      modelo:['', Validators.required],
      ano:['', Validators.required],
      email:['', [Validators.required, Validators.email]]
    });
  }

  validate(){
    
    if(this.myGroup.valid){
      this.data.emit({marca:this.myGroup.controls.marca.value, modelo:this.myGroup.controls.modelo.value, email:this.myGroup.controls.email.value});
    }else{
      console.log(this.myGroup.controls);
      if(!this.myGroup.controls.marca.valid){
        swal.fire('Error!', 'Debes seleccionar una marca', 'error');
      }else if(!this.myGroup.controls.modelo.valid){
        swal.fire('Error!', 'Debes seleccionar un modelo', 'error');
      }else if(!this.myGroup.controls.ano.valid){
        swal.fire('Error!', 'Debes seleccionar el año del auto', 'error');
      }else if(!this.myGroup.controls.email.valid){
        swal.fire('Error!', 'Debes ingresar un email valido', 'error');
      }
    }
    
  }

}
